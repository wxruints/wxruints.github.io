#!/system/bin/sh

echo "正在尝试跳转到QQ群961805556..."
echo "qq群:961805556"

# 先尝试使用QQ跳转
if am start -a android.intent.action.VIEW -d "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=961805556&card_type=group&source=qrcode" 2>/dev/null; then
    echo "已跳转到QQ群聊页面"
else
    # 如果QQ失败，尝试使用TIM
    echo "QQ跳转失败，尝试使用TIM跳转..."
    if am start -a android.intent.action.VIEW -d "timapi://card/show_pslcard?src_type=internal&version=1&uin=961805556&card_type=group&source=qrcode" 2>/dev/null; then
        echo "已跳转到TIM群聊页面"
    else
        # 如果TIM也失败，尝试直接打开TIM
        echo "跳转失败，直接打开TIM..."
        if am start -n com.tencent.tim/com.tencent.mobileqq.activity.JumpActivity 2>/dev/null; then
            echo "已打开TIM，请手动搜索群号 961805556"
        else
            echo "所有跳转方式均失败，请手动打开TIM并搜索群号 961805556"
        fi
    fi
fi
