#!/system/bin/sh
# 与watchdog.sh保持一致的核心路径变量
MODULE_DIR="/data/adb/modules/kill_dd"
FX_FILE="/dev/FSX/current_bin.txt"
LOG_FILE="$MODULE_DIR/guard.log"
WATCHDOG_SCRIPT="watchdog.sh" # 明确要杀死的watchdog脚本名

# 复用：检查进程是否运行（与watchdog.sh逻辑一致）
is_bin_running() {
    local bin_name=$1
    pgrep -f "$bin_name" >/dev/null 2>&1
}

# 核心：获取/dev/FSX中记录的8位数字主脚本（严格匹配8位数字格式）
get_target_bin() {
    local target_bin=""
    # 1. 优先读取current_bin.txt（必须是8位数字.sh脚本）
    if [ -f "$FX_FILE" ] && [ -s "$FX_FILE" ]; then
        target_bin=$(cat "$FX_FILE")
        # 验证：路径包含8位数字.sh，且文件存在
        if [ -f "$target_bin" ] && echo "$target_bin" | grep -qE '/[0-9]{8}\.sh$'; then
            echo "$target_bin"
            return 0
        fi
    fi
    # 2. 若FX文件无效，查找模块目录下的8位数字.sh（备用逻辑）
    target_bin=$(ls "$MODULE_DIR"/*.sh 2>/dev/null | grep -E '/[0-9]{8}\.sh$' | head -n 1)
    if [ -n "$target_bin" ] && [ -f "$target_bin" ]; then
        echo "$target_bin"
        return 0
    fi
    # 无有效8位数字主脚本
    echo ""
    return 1
}

# 主逻辑：先杀8位数字主进程，再杀watchdog进程
main() {
    local target_bin=$(get_target_bin)
    local log_time=$(date +'%F %T')

    # 第一步：处理8位数字主进程
    if [ -z "$target_bin" ]; then
        echo "[$log_time] 停用模块：[ERROR] 未找到8位数字主脚本（/dev/FSX或模块目录）" >> "$LOG_FILE"
    else
        if is_bin_running "$target_bin"; then
            local pid=$(pgrep -f "$target_bin")
            kill -9 "$pid" >/dev/null 2>&1
            if ! is_bin_running "$target_bin"; then
                echo "[$log_time] 停用模块：成功杀死8位主进程，脚本=$target_bin，PID=$pid" >> "$LOG_FILE"
            else
                echo "[$log_time] 停用模块：[ERROR] 杀死8位主进程失败，脚本=$target_bin，PID=$pid" >> "$LOG_FILE"
            fi
        else
            echo "[$log_time] 停用模块：8位主进程未运行，脚本=$target_bin" >> "$LOG_FILE"
        fi
    fi

    # 第二步：处理watchdog.sh进程
    if is_bin_running "$WATCHDOG_SCRIPT"; then
        local wd_pid=$(pgrep -f "$WATCHDOG_SCRIPT")
        kill -9 "$wd_pid" >/dev/null 2>&1
        if ! is_bin_running "$WATCHDOG_SCRIPT"; then
            echo "[$log_time] 停用模块：成功杀死watchdog.sh，PID=$wd_pid" >> "$LOG_FILE"
        else
            echo "[$log_time] 停用模块：[ERROR] 杀死watchdog.sh失败，PID=$wd_pid" >> "$LOG_FILE"
        fi
    else
        echo "[$log_time] 停用模块：watchdog.sh未运行" >> "$LOG_FILE"
    fi

    # 复用：日志大小控制（超过50KB清空）
    if [ -f "$LOG_FILE" ] && [ $(wc -c < "$LOG_FILE") -gt 51200 ]; then
        echo "[$(date +'%F %T')] 停用模块：日志超过50KB，清空" > "$LOG_FILE"
    fi
}

main
