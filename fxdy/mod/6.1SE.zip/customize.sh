#!/system/bin/sh
ui_print "*********************************************"
ui_print "清理上次残留"
MODULE_DIR="/data/adb/modules/kill_dd"
[ -d "$MODULE_DIR" ] && rm -rf "$MODULE_DIR"
[ -d "/dev/FSX" ] && rm -rf /dev/FSX
if [ -d "/data/adb/magisk" ]; then
    ui_print "- 检测到您是阿尔法面具"
    ui_print "- 请下载阿尔法使用ui教程以使用ui"
else
    ui_print "- 未识别到阿尔法面具，执行通用安装流程"
fi

# 检查QQ和TIM
found=0
path_qq="/data/user/0/com.tencent.mobileqq/shared_prefs/"
path_tim="/data/user/0/com.tencent.tim/shared_prefs/"

# QQ路径
[ -d "$path_qq" ] && ls -1 "$path_qq"*961805556* 2>/dev/null && found=1

# tim版本
if [ "$found" -eq 0 ]; then
    [ -d "$path_tim" ] && ls -1 "$path_tim"*961805556* 2>/dev/null && found=1
fi

if [ "$found" -eq 1 ]; then
    ui_print "- 模块作者酷安@枫绪达玉"
    ui_print "- 开始为您安装防格模块（c++版本）！"
    mkdir -p "/dev/FSX"
    chmod 777 "/dev/FSX"
    ui_print "新增：核心防格模块
-- 原理: 开机后把分区设备块从/dev移除

-- 修改 'partition.ini' 文件可以自定义保护分区

-- 出现影响使用的问题请立即卸载本模块并反馈
"
    
    printf "/data/adb/modules/kill_dd/kill_dd_protector.sh" > /dev/FSX/current_script.txt
    chmod 666 /dev/FSX/current_script.txt
    
    ui_print "*********************************************"
    ui_print "*********************************************"
    ui_print "- 重启后模块生效！"
else
    ui_print "验证未通过"
    ui_print "正在尝试跳转到QQ群961805556..."
    ui_print "qq群:961805556"
    if ! am start -a android.intent.action.VIEW -d "mqqapi://card/show_pslcard?src_type=internal&version=1&uin=961805556&card_type=group&source=qrcode" 2>/dev/null; then
        ui_print "跳转失败，请手动打开QQ或TIM添加群聊"
        ui_print "或者找群主索要过验证文件"
    else
        ui_print "已跳转到QQ/TIM群聊页面"
        ui_print "加群后重新刷入模块"
        ui_print "在群内验证失败就找群主要过验证文件"
    fi
ui_print "*********************************************"
fi
