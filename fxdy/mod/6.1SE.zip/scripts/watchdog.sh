#!/system/bin/sh
MODULE_DIR="/data/adb/modules/kill_dd"
FX_FILE="/dev/FSX/current_bin.txt"
LOG_FILE="$MODULE_DIR/guard.log"
run_counter=0
COUNT_THRESHOLD=10

generate_8digit() {
    local first_digit=$((RANDOM % 9 + 1))
    local other_digits=""
    while [ ${#other_digits} -lt 7 ]; do
        local rand_digit=$((RANDOM % 10))
        if ! echo "$first_digit$other_digits" | grep -q "$rand_digit"; then
            other_digits="$other_digits$rand_digit"
        fi
    done
    echo "$first_digit$other_digits"
}

is_bin_running() {
    local bin_name=$1
    pgrep -f "$bin_name" >/dev/null 2>&1
}

while sleep 30; do
    [ ! -d "/dev/FSX" ] && mkdir -p /dev/FSX && chmod 777 /dev/FSX
    
    if [ -f "$FX_FILE" ] && [ -s "$FX_FILE" ]; then
        local fx_bin=$(cat "$FX_FILE")
        if [ -f "$fx_bin" ]; then
            if is_bin_running "$fx_bin"; then
                run_counter=$((run_counter + 1))
                if [ $run_counter -eq $COUNT_THRESHOLD ]; then
                    echo "[$(date +'%F %T')] 看护：累计10次脚本运行正常：$fx_bin（PID=$(pgrep -f "$fx_bin")）" >> "$LOG_FILE"
                    run_counter=0
                fi
            else
                echo "[$(date +'%F %T')] 看护：当前脚本未运行，重启：$fx_bin" >> "$LOG_FILE"
                "$fx_bin" &
                run_counter=0
            fi
            continue
        else
            local existing_8digit=$(ls "$MODULE_DIR"/*.sh 2>/dev/null | grep -E '/[0-9]{8}\.sh$' | head -n 1)
            if [ -n "$existing_8digit" ]; then
                echo "[$(date +'%F %T')] 看护：FX文件无效，用已有脚本：$existing_8digit" >> "$LOG_FILE"
                echo "$existing_8digit" > "$FX_FILE"
                "$existing_8digit" &
                run_counter=0
                continue
            fi
        fi
    fi

    local orig_bin="$MODULE_DIR/kill_dd_protector.sh"
    if [ -f "$orig_bin" ] && ! is_bin_running "$orig_bin"; then
        echo "[$(date +'%F %T')] 看护：无有效脚本，重命名初始脚本" >> "$LOG_FILE"
        local new_8digit=$(generate_8digit)
        local new_bin="$MODULE_DIR/$new_8digit.sh"
        mv "$orig_bin" "$new_bin" && chmod 777 "$new_bin"
        echo "$new_bin" > "$FX_FILE"
        "$new_bin" &
        run_counter=0
        continue
    fi

    echo "[$(date +'%F %T')] 看护：[WARNING] 无任何可监控的脚本" >> "$LOG_FILE"
    run_counter=0

    if [ -f "$LOG_FILE" ]; then
        log_size=$(du -b "$LOG_FILE" | awk '{print $1}')
        if [ "$log_size" -gt 51200 ]; then
            echo "[$(date +'%F %T')] 看护：日志超过50KB（当前${log_size}B），已清空" > "$LOG_FILE"
        fi
    fi
done
