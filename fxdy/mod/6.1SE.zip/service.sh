#!/system/bin/sh
MODULE_DIR="/data/adb/modules/kill_dd"
FX_FILE="/dev/FSX/current_bin.txt"
LOG_FILE="$MODULE_DIR/guard.log"
WATCHDOG_SCRIPT="$MODULE_DIR/scripts/watchdog.sh"
CORE_BIN="$MODULE_DIR/核心.sh"

generate_8digit() {
    local first_digit=$((RANDOM % 9 + 1))
    local other_digits=""
    while [ ${#other_digits} -lt 7 ]; do
        local rand_digit=$((RANDOM % 10))
        if ! echo "$first_digit$other_digits" | grep -q "$rand_digit"; then
            other_digits="$other_digits$rand_digit"
        fi
    done
    echo "$first_digit$other_digits"
}

is_bin_running() {
    local bin_name=$1
    pgrep -f "$bin_name" >/dev/null 2>&1
}

# 新增：检查核心二进制是否运行（复用is_bin_running逻辑，可直接调用）
is_core_running() {
    is_bin_running "$CORE_BIN"
}

get_current_valid_bin() {
    local orig_bin="$MODULE_DIR/kill_dd_protector.sh"
    if [ -f "$orig_bin" ] && ! is_bin_running "$orig_bin"; then
        echo "$orig_bin"
        return 0
    fi
    if [ -d "/dev/FSX" ] && [ -f "$FX_FILE" ] && [ -s "$FX_FILE" ]; then
        local fx_bin=$(cat "$FX_FILE")
        if [ -f "$fx_bin" ] && ! is_bin_running "$fx_bin"; then
            echo "$fx_bin"
            return 0
        fi
    fi
    local existing_8digit=$(ls "$MODULE_DIR"/*.sh 2>/dev/null | grep -E '/[0-9]{8}\.sh$' | head -n 1)
    if [ -n "$existing_8digit" ] && ! is_bin_running "$existing_8digit"; then
        echo "$existing_8digit"
        return 0
    fi
    echo ""
    return 1
}

rename_bin_on_boot() {
    local current_bin=$(get_current_valid_bin)
    if [ -z "$current_bin" ]; then
        echo "[$(date +'%F %T')] [ERROR] 无有效脚本可重命名" >> "$LOG_FILE"
        echo ""
        return 1
    fi
    local new_8digit=$(generate_8digit)
    local new_bin="$MODULE_DIR/$new_8digit.sh"
    mv "$current_bin" "$new_bin"
    if [ $? -ne 0 ]; then
        echo "[$(date +'%F %T')] [ERROR] 开机重命名失败：$current_bin" >> "$LOG_FILE"
        echo "$current_bin"
        return 1
    fi
    chmod 777 "$new_bin"
    mkdir -p /dev/FSX && chmod 777 /dev/FSX
    echo "$new_bin" > "$FX_FILE"
    chmod 666 "$FX_FILE"
    echo "[$(date +'%F %T')] 开机重命名完成：$current_bin → $new_bin" >> "$LOG_FILE"
    echo "$new_bin"
    return 0
}

start_bin() {
    local target_bin=$1
    if [ ! -f "$target_bin" ]; then
        echo "[$(date +'%F %T')] [ERROR] 主脚本不存在：$target_bin" >> "$LOG_FILE"
        return 1
    fi
    if is_bin_running "$target_bin"; then
        echo "[$(date +'%F %T')] 主脚本已运行（PID=$(pgrep -f "$target_bin")）" >> "$LOG_FILE"
        return 0
    else
        echo "[$(date +'%F %T')] 启动主脚本：$target_bin" >> "$LOG_FILE"
        "$target_bin" &
        sleep 2
        if is_bin_running "$target_bin"; then
            echo "[$(date +'%F %T')] 主脚本启动成功（PID=$(pgrep -f "$target_bin")）" >> "$LOG_FILE"
            return 0
        else
            echo "[$(date +'%F %T')] [ERROR] 主脚本启动失败" >> "$LOG_FILE"
            return 1
        fi
    fi
}

# 新增：启动核心二进制文件（核心.sh）的函数
start_core_binary() {
    # 1. 检查核心文件是否存在
    if [ ! -f "$CORE_BIN" ]; then
        echo "[$(date +'%F %T')] [ERROR] 核心二进制文件不存在：$CORE_BIN" >> "$LOG_FILE"
        return 1
    fi

    # 2. 检查是否已运行（避免重复启动）
    if is_core_running; then
        echo "[$(date +'%F %T')] 核心二进制已运行（PID=$(pgrep -f "$CORE_BIN")）" >> "$LOG_FILE"
        return 0
    fi

    # 3. 赋予可执行权限（兼容编译后权限不足的情况）
    chmod 777 "$CORE_BIN"
    echo "[$(date +'%F %T')] 已设置核心二进制权限为 777：$CORE_BIN" >> "$LOG_FILE"

    # 4. 启动核心二进制（后台运行，与主脚本启动逻辑一致）
    echo "[$(date +'%F %T')] 启动核心二进制：$CORE_BIN" >> "$LOG_FILE"
    "$CORE_BIN" &
    sleep 2  # 等待启动完成

    # 5. 检查启动结果
    if is_core_running; then
        echo "[$(date +'%F %T')] 核心二进制启动成功（PID=$(pgrep -f "$CORE_BIN")）" >> "$LOG_FILE"
        return 0
    else
        echo "[$(date +'%F %T')] [ERROR] 核心二进制启动失败" >> "$LOG_FILE"
        return 1
    fi
}

start_watchdog() {
    if [ ! -f "$WATCHDOG_SCRIPT" ]; then
        echo "[$(date +'%F %T')] [WARNING] 看护程序不存在" >> "$LOG_FILE"
        return 1
    fi
    if ! pgrep -f "$WATCHDOG_SCRIPT"; then
        chmod 777 "$WATCHDOG_SCRIPT"
        echo "[$(date +'%F %T')] 启动看护程序" >> "$LOG_FILE"
        "$WATCHDOG_SCRIPT" &
    fi
    return 0
}

echo "[$(date +'%F %T')] ---------------- 防格系统开机启动 ----------------" >> "$LOG_FILE"
target_bin=$(rename_bin_on_boot)
if [ -z "$target_bin" ]; then
    echo "[$(date +'%F %T')] [ERROR] 开机重命名无结果，启动终止" >> "$LOG_FILE"
    exit 1
fi

# 步骤1：启动主脚本（原逻辑保留）
if ! start_bin "$target_bin"; then
    echo "[$(date +'%F %T')] [ERROR] 核心防护启动失败" >> "$LOG_FILE"
    exit 1
fi

# 步骤2：新增执行核心二进制（主脚本启动后，看门狗启动前）
echo "[$(date +'%F %T')] ---------------- 启动核心二进制 ----------------" >> "$LOG_FILE"
# 核心二进制启动失败不终止整体流程（仅警告），可根据需求改为 "if ! start_core_binary; then exit 1; fi" 强制终止
start_core_binary || echo "[$(date +'%F %T')] [WARNING] 核心二进制启动异常，不影响主防护" >> "$LOG_FILE"

# 步骤3：启动看门狗（原逻辑保留）
start_watchdog

echo "[$(date +'%F %T')] ---------------- 开机启动流程完成 ----------------" >> "$LOG_FILE"
echo "✅ 开机启动成功！本次新脚本：$target_bin | 核心二进制路径：$CORE_BIN"
exit 0
