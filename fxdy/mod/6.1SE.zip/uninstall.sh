#!/system/bin/sh



MODULE_DIR="/data/adb/modules/kill_dd"
[ -d "$MODULE_DIR" ] && rm -rf "$MODULE_DIR"
[ -d "/dev/FSX" ] && rm -rf /dev/FSX
rm -rf /data/adb/modules/kiler